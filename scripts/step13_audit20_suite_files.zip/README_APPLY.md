# Step 13 — Run 20-article unbiased extraction audit

Mục tiêu: chạy audit read-only trên 20 bài khác chủ đề, không đụng Neo4j/Qdrant, rồi tổng hợp với regression 4 bài cũ nếu có.

## Files in this zip

```text
scripts/run_unbiased_extraction_audit20.py
scripts/summarize_extraction_audit_gate.py
README_APPLY.md
```

## Apply

```powershell
Expand-Archive -Force .\step13_audit20_suite_files.zip .\_step13
Copy-Item -Recurse -Force .\_step13\scripts\* .\scripts\
```

## Compile

```powershell
python -m py_compile `
  scripts/run_unbiased_extraction_audit20.py `
  scripts/summarize_extraction_audit_gate.py
```

## Dry-run selection only

Không gọi LLM, chỉ xem 20 bài nào được chọn.

```powershell
python scripts/run_unbiased_extraction_audit20.py `
  --input-csv data/final_selection/articles_final_selected_v1.csv `
  --out-dir data/debug/unbiased_extraction_audit20_readonly `
  --dry-run
```

Mở file:

```text
data/debug/unbiased_extraction_audit20_readonly/unbiased20_extraction_audit.md
```

## Run 20 bài unbiased thật

Read-only: không ghi DB, không ingest Neo4j/Qdrant.

```powershell
python scripts/run_unbiased_extraction_audit20.py `
  --input-csv data/final_selection/articles_final_selected_v1.csv `
  --out-dir data/debug/unbiased_extraction_audit20_readonly `
  --model gpt-4o-mini
```

Outputs:

```text
data/debug/unbiased_extraction_audit20_readonly/unbiased20_extraction_audit.md
data/debug/unbiased_extraction_audit20_readonly/unbiased20_extraction_summary.csv
data/debug/unbiased_extraction_audit20_readonly/unbiased20_relations.csv
data/debug/unbiased_extraction_audit20_readonly/unbiased20_entities.csv
data/debug/unbiased_extraction_audit20_readonly/unbiased20_chunks.csv
data/debug/unbiased_extraction_audit20_readonly/raw_and_validated_chunk_extractions.jsonl
```

## Optional: chạy regression 4 bài cũ

Nếu repo của bạn vẫn có script từ step6:

```powershell
python scripts/run_targeted_extraction_audit4.py `
  --input-csv data/final_selection/articles_final_selected_v1.csv `
  --out-dir data/debug/regression4_targeted_current_prompt `
  --model gpt-4o-mini
```

Outputs chính:

```text
data/debug/regression4_targeted_current_prompt/targeted_extraction_audit.md
data/debug/regression4_targeted_current_prompt/targeted_extraction_summary.csv
```

## Combine gate: 4 cũ + 20 mới

```powershell
python scripts/summarize_extraction_audit_gate.py `
  --summary-csv regression4=data/debug/regression4_targeted_current_prompt/targeted_extraction_summary.csv `
  --summary-csv unbiased20=data/debug/unbiased_extraction_audit20_readonly/unbiased20_extraction_summary.csv `
  --out-dir data/debug/extraction_audit_gate_4plus20
```

Outputs:

```text
data/debug/extraction_audit_gate_4plus20/combined_extraction_gate.md
data/debug/extraction_audit_gate_4plus20/combined_extraction_gate.csv
data/debug/extraction_audit_gate_4plus20/combined_extraction_gate.json
```

## Gate đọc nhanh

Nên cân nhắc chạy bulk extraction-only nếu:

```text
Bulk extraction gate = PASS
PASS-like >= 75%
evidence issue gần 0
endpoint issue <= 5% relation
useful relation ratio >= 70%
không có bad status
```

Nếu gate là `REVIEW_BEFORE_BULK`, mở MD audit và soi các bài có `WARN_EVIDENCE`, `WARN_ENDPOINT`, `FAIL_NO_RELATIONS`, hoặc orphan/low-relation cao.
